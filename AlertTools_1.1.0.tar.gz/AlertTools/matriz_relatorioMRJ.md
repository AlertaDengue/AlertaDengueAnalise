---
title: "Info Dengue Rio"
author: "Relatório de situação da dengue na cidade do Rio de Janeiro"
output: pdf_document
geometry: margin=0.5in
fontsize: 12pt
---







**Rio de Janeiro, 2016-05-31**


Confira a situação da dengue na cidade do Rio de Janeiro. Mais detalhes, ver: [info.dengue.mat.br](info.dengue.mat.br) 

## Índice {#top}
* [Mapa](#mapa)
* [Na cidade](#tab1)
* [Dados por APS](#aps)
* [Notas](#notas)

**Código de Cores do Alerta por APS**

*Verde (atividade baixa)*
   temperatura < 22 graus por 3 semanas 
   atividade de tweet normal (não aumentada)
   ausência de transmissão sustentada

*Amarelo (Alerta)*
   temperatura > 22C por mais de 3 semanas
   ou atividade de tweet aumentada

*Laranja (Transmissão sustentada)*
  número reprodutivo >1 por 3 semanas

*Vermelho (atividade alta)*
 incidência acima do percentil 90 (100:100.000 habitantes)

\newpage

### Mapa da Cidade do Rio de Janeiro {#mapa}

As sub-divisões são as áreas programáticas da saúde. Verde indica atividade baixa, amarelo indica vulnerabilidade, laranja indica transmissão sustentada e vermelho indica incidência acima do percentil 90.

![plot of chunk unnamed-chunk-3](figure/unnamed-chunk-3-1.pdf)

Veja o mapa interativo em [Alerta Dengue](http://alerta.dengue.mat.br)
<br> </br>
<p> </p>

\newpage

<br> </br>

### <a name="tab1"></a> Situação da dengue na cidade do Rio de Janeiro




![plot of chunk unnamed-chunk-5](figure/unnamed-chunk-5-1.pdf)


\newpage

Últimas 6 semanas:

- SE: semana epidemiológica
- casos: número de casos de dengue no SINAN
- casos_corrigidos: estimativa do número de casos notificados (ver [Notas](#notas))
- tweets: número de tweets relatando sintomas de dengue (ver [Notas](#notas))
- tmin: média das temperaturas mínimas da semana
- inc: incidência por 100.000 habitantes


---------------------------------------------------------------------
  se    casos   casos.estimados   ICmin   ICmax   inc   tweet   tmin 
------ ------- ----------------- ------- ------- ----- ------- ------
201616  1438         1438         1438    1438   22.12   126   23.86 

201617  1907         1907         1907    1907   29.34   105   21.86 

201618   784          784          784     784   12.06   99    19.86 

201619   777          777          777     777   11.95   90    21.57 

201620   699          699          699     699   10.75   119   21.29 

201621   515         1584         1482    1614   7.923   51    20.29 
---------------------------------------------------------------------

\newpage


### Alerta por APS {#aps}
A linha tracejada verde indica o limiar pré-epidêmico; a linha tracejada vermelha indica o limiar de atividade alta (acima do qual é acionado o alerta vermelho). 

![plot of chunk unnamed-chunk-7](figure/unnamed-chunk-7-1.pdf)

\newpage

![plot of chunk unnamed-chunk-8](figure/unnamed-chunk-8-1.pdf)

\newpage
### Tabelas com os dados das últimas quatro semanas por APS

casos not = casos notificados, casos est = casos estimados após correção do atraso de notificação, tmin = temperatura mínima da semana, Rt = número reprodutivo, se maior que 1, indica que os casos estão com tendência de aumento, prob(Rt > 1) = p-valor do teste se Rt >1,
inc = incidência por 100.000 habitantes, nivel de 1 a 4 indica verde a vermelho.


```
## Área Programática da Saúde 1.0
```

<br> </br>


------------------------------------------------------------------------
  SE    casos not   casos est   tmin    Rt     prob(Rt>1)   inc   nivel 
------ ----------- ----------- ------ ------- ------------ ----- -------
201618     51          51      19.86  0.4065   5.698e-09   22.47    2   

201619      8           8      21.57  0.09171      0       3.525    2   

201620     10          10      21.29  0.1892   5.686e-09   4.406    2   

201621      3           7      20.29  0.2905   0.0006827   3.084    1   
------------------------------------------------------------------------



```
## Área Programática da Saúde 2.1
```

<br> </br>



-------------------------------------------------------------------------
  SE    casos not   casos est   tmin    Rt     prob(Rt>1)   inc    nivel 
------ ----------- ----------- ------ ------- ------------ ------ -------
201618     30          30      19.86   1.098     0.6392    5.428     2   

201619     22          22      21.57  0.7653     0.1694    3.981     1   

201620     16          16      21.29  0.5788    0.03669    2.895     1   

201621      1           2      20.29  0.09113   2.96e-06   0.3619    1   
-------------------------------------------------------------------------




```
## Área Programática da Saúde 2.2
```

<br> </br>



-----------------------------------------------------------------------
  SE    casos not   casos est   tmin    Rt    prob(Rt>1)   inc   nivel 
------ ----------- ----------- ------ ------ ------------ ----- -------
201618     68          68      19.86  0.445   3.465e-09   18.32    2   

201619     58          58      21.57  0.6509   0.004909   15.63    2   

201620     49          49      21.29  0.7218   0.03948    13.2     2   

201621     66          200     20.29  2.999       1       53.89    2   
-----------------------------------------------------------------------



```
## Área Programática da Saúde 3.1
```

<br> </br>

\newpage


-----------------------------------------------------------------------
  SE    casos not   casos est   tmin    Rt    prob(Rt>1)   inc   nivel 
------ ----------- ----------- ------ ------ ------------ ----- -------
201618     140         140     19.86  0.4552  4.441e-16   19.03    2   

201619     276         276     21.57   1.03     0.637     37.51    2   

201620     253         253     21.29  1.086     0.8178    34.38    2   

201621     126         390     20.29  1.589       1        53      2   
-----------------------------------------------------------------------



```
## Área Programática da Saúde 3.2
```

<br> </br>



-----------------------------------------------------------------------
  SE    casos not   casos est   tmin    Rt    prob(Rt>1)   inc   nivel 
------ ----------- ----------- ------ ------ ------------ ----- -------
201618     75          75      19.86  0.584   7.959e-05   15.31    2   

201619     35          35      21.57  0.3205  1.073e-10   7.147    2   

201620     42          42      21.29  0.5374  0.0004253   8.576    2   

201621      6          15      20.29  0.2981  3.049e-06   3.063    1   
-----------------------------------------------------------------------


```
## Área Programática da Saúde 3.3
```

<br> </br>


-----------------------------------------------------------------------
  SE    casos not   casos est   tmin    Rt    prob(Rt>1)   inc   nivel 
------ ----------- ----------- ------ ------ ------------ ----- -------
201618     60          60      19.86  0.3427  7.661e-15   6.491    2   

201619     57          57      21.57  0.4138  1.962e-09   6.166    2   

201620     107         107     21.29  1.123     0.7948    11.58    1   

201621     285         895     20.29  7.356       1       96.82    1   
-----------------------------------------------------------------------


```
## Área Programática da Saúde 4.0
```

<br> </br>



-----------------------------------------------------------------------
  SE    casos not   casos est   tmin    Rt    prob(Rt>1)   inc   nivel 
------ ----------- ----------- ------ ------ ------------ ----- -------
201618     81          81      19.86  0.5039  1.074e-07   9.656    2   

201619     92          92      21.57  0.4791  9.338e-10   10.97    2   

201620     102         102     21.29  0.6694  0.0007527   12.16    1   

201621      9          24      20.29  0.2345  1.924e-13   2.861    1   
-----------------------------------------------------------------------



```
## Área Programática da Saúde 5.1
```

<br> </br>



-----------------------------------------------------------------------
  SE    casos not   casos est   tmin    Rt    prob(Rt>1)   inc   nivel 
------ ----------- ----------- ------ ------ ------------ ----- -------
201618     172         172     19.86  0.3319      0       26.22    2   

201619     142         142     21.57  0.3408      0       21.65    2   

201620     53          53      21.29  0.1992      0       8.081    2   

201621      7          18      20.29  0.1252      0       2.744    2   
-----------------------------------------------------------------------




```
## Área Programática da Saúde 5.2
```

<br> </br>



-----------------------------------------------------------------------
  SE    casos not   casos est   tmin    Rt    prob(Rt>1)   inc   nivel 
------ ----------- ----------- ------ ------ ------------ ----- -------
201618     61          61      19.86  0.7492   0.04282    9.17     2   

201619     58          58      21.57  0.816     0.1239    8.719    1   

201620     50          50      21.29  0.7875    0.1016    7.517    1   

201621     12          33      20.29  0.5877   0.006603   4.961    1   
-----------------------------------------------------------------------



```
## Área Programática da Saúde 5.3
```

<br> </br>



-----------------------------------------------------------------------
  SE    casos not   casos est   tmin    Rt    prob(Rt>1)   inc   nivel 
------ ----------- ----------- ------ ------ ------------ ----- -------
201618     46          46      19.86  0.4653   4.16e-06   12.48    2   

201619     29          29      21.57  0.3812   1.33e-06   7.869    2   

201620     17          17      21.29  0.3314  9.525e-06   4.613    1   

201621      0           0      20.29    0         0         0      1   
-----------------------------------------------------------------------
[volta](#top)

<br> </br>


\newpage

### Notas {#notas}


- Os dados do sinan mais recentes ainda não foram totalmente digitados. Estimamos o número esperado de casos
notificados considerando o tempo ate os casos serem digitados.
- Os dados de tweets são gerados pelo Observatório de Dengue (UFMG). Os tweets são processados para exclusão de informes e outros temas relacionados a dengue
- Algumas vezes, os casos da última semana ainda não estao disponiveis, nesse caso, usa-se uma estimação com base na tendência de variação da serie 

Créditos
------
Esse e um projeto desenvolvido em parceria pela Fiocruz, FGV e Prefeitura do Rio de Janeiro, com apoio da SVS/MS

Mais detalhes do projeto , ver: [www.dengue.mat.br](www.dengue.mat.br) 

<br> </br>
------------
<br> </br>




[volta](#top)
