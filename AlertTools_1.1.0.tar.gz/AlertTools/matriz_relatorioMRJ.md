---
title: "Info Dengue Rio"
author: "Relatório de situação da dengue na cidade do Rio de Janeiro"
output: pdf_document
geometry: margin=0.5in
fontsize: 12pt
---







**Rio de Janeiro, 2016-06-21**


Confira a situação da dengue na cidade do Rio de Janeiro. Mais detalhes, ver: [info.dengue.mat.br](info.dengue.mat.br) 

## Índice {#top}
* [Mapa](#mapa)
* [Na cidade](#tab1)
* [Dados por APS](#aps)
* [Notas](#notas)

**Código de Cores do Alerta por APS**

*Verde (atividade baixa)*
   temperatura < 22 graus por 3 semanas 
   atividade de tweet normal (não aumentada)
   ausência de transmissão sustentada

*Amarelo (Alerta)*
   temperatura > 22C por mais de 3 semanas
   ou atividade de tweet aumentada

*Laranja (Transmissão sustentada)*
  número reprodutivo >1 por 3 semanas

*Vermelho (atividade alta)*
 incidência acima do percentil 90 (100:100.000 habitantes)

\newpage

### Mapa da Cidade do Rio de Janeiro {#mapa}

As sub-divisões são as áreas programáticas da saúde. Verde indica atividade baixa, amarelo indica vulnerabilidade, laranja indica transmissão sustentada e vermelho indica incidência acima do percentil 90.

![](Rio_de_Janeiro/mapaRio.png)

Veja o mapa interativo em [Alerta Dengue](http://alerta.dengue.mat.br)
<br> </br>
<p> </p>

\newpage

<br> </br>

### <a name="tab1"></a> Situação da dengue na cidade do Rio de Janeiro




![plot of chunk unnamed-chunk-4](figure/unnamed-chunk-4-1.png)


\newpage

Últimas 6 semanas:

- SE: semana epidemiológica
- casos: número de casos de dengue no SINAN
- casos_corrigidos: estimativa do número de casos notificados (ver [Notas](#notas))
- tweets: número de tweets relatando sintomas de dengue (ver [Notas](#notas))
- tmin: média das temperaturas mínimas da semana
- inc: incidência por 100.000 habitantes


```
## Error in library(pander): there is no package called 'pander'
```

```
## Error in eval(expr, envir, enclos): could not find function "panderOptions"
```

```
## Error in eval(expr, envir, enclos): could not find function "pander"
```

\newpage


### Alerta por APS {#aps}
A linha tracejada verde indica o limiar pré-epidêmico; a linha tracejada vermelha indica o limiar de atividade alta (acima do qual é acionado o alerta vermelho). 

![plot of chunk unnamed-chunk-6](figure/unnamed-chunk-6-1.png)

\newpage

![plot of chunk unnamed-chunk-7](figure/unnamed-chunk-7-1.png)

\newpage
### Tabelas com os dados das últimas quatro semanas por APS

casos not = casos notificados, casos est = casos estimados após correção do atraso de notificação, tmin = temperatura mínima da semana, Rt = número reprodutivo, se maior que 1, indica que os casos estão com tendência de aumento, prob(Rt > 1) = p-valor do teste se Rt >1,
inc = incidência por 100.000 habitantes, nivel de 1 a 4 indica verde a vermelho.


```
## Error in eval(expr, envir, enclos): could not find function "panderOptions"
```

```
## Área Programática da Saúde 1.0
```

<br> </br>


```
## Error in eval(expr, envir, enclos): could not find function "pander"
```



```
## Área Programática da Saúde 2.1
```

<br> </br>



```
## Error in eval(expr, envir, enclos): could not find function "pander"
```




```
## Área Programática da Saúde 2.2
```

<br> </br>



```
## Error in eval(expr, envir, enclos): could not find function "pander"
```



```
## Área Programática da Saúde 3.1
```

<br> </br>

\newpage


```
## Error in eval(expr, envir, enclos): could not find function "pander"
```



```
## Área Programática da Saúde 3.2
```

<br> </br>



```
## Error in eval(expr, envir, enclos): could not find function "pander"
```


```
## Área Programática da Saúde 3.3
```

<br> </br>


```
## Error in eval(expr, envir, enclos): could not find function "pander"
```


```
## Área Programática da Saúde 4.0
```

<br> </br>



```
## Error in eval(expr, envir, enclos): could not find function "pander"
```



```
## Área Programática da Saúde 5.1
```

<br> </br>



```
## Error in eval(expr, envir, enclos): could not find function "pander"
```




```
## Área Programática da Saúde 5.2
```

<br> </br>



```
## Error in eval(expr, envir, enclos): could not find function "pander"
```



```
## Área Programática da Saúde 5.3
```

<br> </br>



```
## Error in eval(expr, envir, enclos): could not find function "pander"
```
[volta](#top)

<br> </br>


\newpage

### Notas {#notas}


- Os dados do sinan mais recentes ainda não foram totalmente digitados. Estimamos o número esperado de casos
notificados considerando o tempo ate os casos serem digitados.
- Os dados de tweets são gerados pelo Observatório de Dengue (UFMG). Os tweets são processados para exclusão de informes e outros temas relacionados a dengue
- Algumas vezes, os casos da última semana ainda não estao disponiveis, nesse caso, usa-se uma estimação com base na tendência de variação da serie 

Créditos
------
Esse e um projeto desenvolvido em parceria pela Fiocruz, FGV e Prefeitura do Rio de Janeiro, com apoio da SVS/MS

Mais detalhes do projeto , ver: [www.dengue.mat.br](www.dengue.mat.br) 

<br> </br>
------------
<br> </br>




[volta](#top)
