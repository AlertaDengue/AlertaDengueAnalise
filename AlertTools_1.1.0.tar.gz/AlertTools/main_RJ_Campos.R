# =============================================================================
# Arquivo de configuracao e execução do Alerta Dengue: Estado do Rio de Janeiro
# =============================================================================
rm(list=c()) # limpar o workspace

library(foreign)
library("RPostgreSQL")
library(AlertTools)
mapadados <- read.csv("report/ERJdata.csv")
mapadados$nivel <- 0
hoje = Sys.Date()

# =========================
# Abrindo o banco de dados
# =========================
con <- DenguedbConnect()
dbListTables(con)


# -------------------------------------------
## Verificacoes: os dados estao atualizados?
# -------------------------------------------

## Ultima data de notificacao presente no sinan
lastDBdate("sinan")
## Ultima data de notificacao presente no tweet
lastDBdate("tweet")
## Ultima data de notificacao presente no tweet
lastDBdate("clima_wu")
## Ultima data de notificacao presente no historico do alerta
lastDBdate("historico")
# cidade especifica: 
lastDBdate("sinan", city=330100)
lastDBdate("sinan", city=330455)

# ========================================
# Quer salvar o resultado do Alerta no Banco de Dados? 
escreverBD <- FALSE   # use TRUE apenas quando tiver seguro pois irá aparecer no mapa

# ========================================
## PARAMETROS DEFAULT DO MODELO DO ALERTA
# -=======================================

#pdig = plnorm((1:20)*7, 2.5016, 1.1013) # prop de notific por semana atraso
# PS. Esses ajustes vem de modelos lognormais ajustados aos dados. Apenas o da regiao norte, que no original
# era muito atrasado, decidimos usar o da regiao metropolitana (segundo mais atrasado). Isso porque estava
# gerando um aumento de 20 vezes no numero de casos (original da regiao Norte: 3.299, 0.8354). 
pdigCampos <- data.frame(regiao = c("Norte"), media =  c(2.997765), sd = c(0.7859499))


# distribuicao do tempo de geracao 
gtdist="normal"
meangt=3
sdgt = 1.2

# (criterio, duracao da condicao para turnon, turnoff)
crity <- c("temp_min > 22 | (temp_min < 22 & p1 > 0.90)", 3, 3) # criterios para alerta amarelo
crito <- c("p1 > 0.90", 3, 3) # criterios para alerta laranja 
critr <- c("inc > 100", 2, 1) # # criterios para alerta vermelho


#==========================================
# ALERTA POR CIDADE
#==========================================

# Definir a data alvo para o relatorio. A principio, 2 semanas de atraso, depois vemos como 
# melhorar isso
datafim = 201621

#------------------------------
# REGIÃO 02 - NORTE FLUMINENSE
regiao = "Norte"
#------------------------------
# Campos dos Goytacazes: 
#-----------------------------
# PS. As funcoes estao definidas para essa cidade e repetidas nas outras

cidade = 330100
nick = "Campos"
estacoeswu = "SBCP" #Campos

# Run pipeline funtion
run.pipeline <- function(cidade,nick,estacoeswu, regiao, escreverBD=escreverBD){
  dC0 = getCases(city = cidade, datasource = con) # consulta dados do sinan -  
  dT = getTweet(city = cidade, lastday = Sys.Date(),datasource = con) # consulta dados do tweet
  dW = getWU(stations = estacoeswu,var="temp_min",datasource = con) # consulta dados do clima
  
  d <- mergedata(cases = dC0, climate = dW, tweet = dT, ini=20101)  # junta os dados
  d$temp_min <- nafill(d$temp_min, rule="linear")  # interpolacao clima NOVO
  d$casos <- nafill(d$casos, "zero") # preenche de zeros o final da serie NOVO
  
  d <- subset(d,SE<=datafim)
  pdig <- plnorm((1:20)*7, pdigCampos$media[pdigCampos$regiao == regiao], 
                 pdigCampos$sd[pdigCampos$regiao == regiao])[2:20]
  dC2 <- adjustIncidence(d, pdig = pdig) # ajusta a incidencia
  dC3 <- Rt(dC2, count = "tcasesmed", gtdist=gtdist, meangt=meangt, sdgt = sdgt) # calcula Rt
  
  alerta <- fouralert(dC3, cy = crity, co = crito, cr = critr, pop=dC0$pop[1], miss="last") # calcula alerta
  
  if (escreverBD == TRUE) {
    res <- write.alerta(alerta, write = "db")
    write.csv(alerta,file=paste("memoria\\", cidade,hoje,".csv",sep="")) 
  }
  # informacao para o mapa
  alerta
}

alerta <- run.pipeline(cidade, nick,estacoeswu,regiao=regiao,escreverBD = escreverBD)

# Generate Figure
figrelatorio <- function(alerta, nick, mapadados){
  filename = paste("report/",nick,".png",sep="")
  #coefs <- coef(lm(alerta$data$casos~alerta$data$tweet))
  
  png(filename, width = 16, height = 15, units="cm", res=100)
  layout(matrix(1:3, nrow = 3, byrow = TRUE), widths = lcm(15), 
         heights = c(rep(lcm(4),2), lcm(5)))
  
  # separação dos eixos para casos de dengue e tweets 
  
  par(mai=c(0,0,0,0),mar=c(1,4,0,3))
  
  plot(alerta$data$casos, type="l", xlab="", ylab="", axes=FALSE)
  axis(1, pos=0, lty=0, lab=FALSE)
  axis(2)
  mtext(text="Casos de Dengue", line=2.5,side=2, cex = 0.7)
  maxy <- max(alerta$data$casos, na.rm=TRUE)
  legend(25, maxy, c("casos de dengue","tweets"),col=c(1,3), lty=1, bty="n",cex=0.7)
  par(new=T)
  plot(alerta$data$tweet, col=3, type="l", axes=FALSE , xlab="", ylab="" ) #*coefs[2] + coefs[1]
  lines(alerta$data$tweet, col=3, type="h") #*coefs[2] + coefs[1]
  axis(1, pos=0, lty=0, lab=FALSE)
  axis(4)
  mtext(text="Tweets", line=2.5, side=4, cex = 0.7)
  
  #original
  #plot(alerta$data$casos, type="l", xlab="", ylab="número", axes=FALSE)
  #lines(alerta$data$tweet*coefs[2] + coefs[1], col=3, type="l")
  #lines(alerta$data$tweet*coefs[2] + coefs[1], col=3, type="h")
  #lines(alerta$data$casos)
  #axis(2)
  #maxy <- max(alerta$data$casos, na.rm=TRUE)
  #legend(100, maxy, c("casos de dengue","f(tweets)"),col=c(1,3), lty=1, bty="n",cex=0.7)
  
  par(mai=c(0,0,0,0),mar=c(1,4,0,3))
  plot(alerta$data$temp_min, type="l", xlab="", ylab ="Temperatura",axes=FALSE)
  axis(2)
  abline(h=22, lty=2)
  
  par(mai=c(0,0,0,0),mar=c(1,4,0,4))
  #par(mar=c(4,4,1,1))
  plot.alerta(alerta, var="tcasesmed",ini=201301,fim=max(alerta$data$SE))
  abline(h=100/100000*alerta$data$pop[1],lty=3)
  dev.off()
  message(paste("Figura salva da cidade", nick))
  mapadados$SE[mapadados$CD_GEOCMU==alerta$data$cidade[1]]<- max(alerta$data$SE)
  mapadados$nivel[mapadados$CD_GEOCMU==alerta$data$cidade[1]]<-tail(alerta$indices$level,1)
  mapadados
}

mapadados <- figrelatorio(alerta, nick, mapadados)
save(alerta,file=paste("report/",nick,".RData",sep=""))
